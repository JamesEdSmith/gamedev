Pike 'n Shot
==========================================
A game by Smith's Fine Electric Amusements


CONtrols
==========================================

arrow keys - movement

Z:     Pike!
X:     Shot!
Z + X: Doppel Soldier attack

ESC: quit
CTRL + 1: restart game
CTRL + 9: toggle CRT shader mode
CTRL + 0: toggle fullscreen

FURTHER INSTRUCTIONS
==========================================

Kill Saurian raiders until they are all 
vanquished.

If you run out of money your army of mercs
will retreat (game over)

Earn PHAT LOOTS by killing ranged or
shielded heavy infantry to keep your mercs
paid and fighting.

Pikes cannot harm shielded opponents. 
Break 'em with shots first or hack them
down with a Doppel Soldier.

Doppel soldiers earn double! Add them to
your formation by filling up the second
coffer bar without taking a loss.

Taking a loss while the doppel coffer is
up will forfeit the entire bar.