Z - Pike
X - Shot
A & s - add troops

arrows - walk around